<?php
define('APP_DEBUG',true); // 开启调试模式
define('APP_NAME','Admin');
define('APP_PATH','./Admin/');
require './ThinkPHP.php';
//App::run();
?>
