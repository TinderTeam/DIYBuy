<?php
define('APP_DEBUG',true); // 开启调试模式
define('APP_NAME','Home');
define('APP_PATH','./Home/');
require './ThinkPHP.php';
?>